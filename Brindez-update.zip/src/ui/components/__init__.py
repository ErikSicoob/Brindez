from .form_dialog import FormDialog
from .form_inline import FormInline

__all__ = ['FormDialog', 'FormInline']